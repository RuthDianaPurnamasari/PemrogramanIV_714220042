package com.example.uts_714220042

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
